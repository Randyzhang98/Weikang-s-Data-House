#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    cout << "IIII is "  << 7/5 << endl;
    return 0;
}